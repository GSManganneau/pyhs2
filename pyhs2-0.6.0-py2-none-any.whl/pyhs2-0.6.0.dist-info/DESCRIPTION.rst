===========
pyhs2
===========
2016-01-05: pyhs2 is no longer being maintained after I failed to find someone who could lead the project. There are quite a few awesome alternatives out there:
* https://github.com/cloudera/impyla
* https://github.com/dropbox/PyHive


2015-06-09: Hi All, my technology stack has migrated off of Hive, thus I am unable to maintain this library. I am looking for a new owner, please let me know if you are interested, there are a TON of work that needs to be completed including:
- Better dependency handling
- Fixing Memory Leak Issues/Handling large data sets
- Building Kerberos implementation
- Native SASL implementation

pyHS2 is a python client driver for connecting to hive server 2.

See example.py for an example of how to use it.

Please log all issues/new feature requests under the issues.

Enjoy


